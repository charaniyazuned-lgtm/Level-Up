LEVEL UP — iPhone-friendly personal tracker

CONTENTS
- index.html: the app
- manifest.json: installable web-app metadata
- sw.js: basic offline cache

HOW TO USE
1. Open index.html in a browser to try it.
2. Your checklist, study logs, workout logs and routine settings are saved in that browser's local storage on that device.
3. Use Routine > Export backup regularly. Import backup restores it.

ADD TO IPHONE HOME SCREEN
For the full installable website experience, the files need to be hosted on an HTTPS website.
A free option is GitHub Pages:
1. Create/sign in to GitHub.
2. Create a public repository, e.g. level-up.
3. Upload index.html, manifest.json and sw.js to the repository root.
4. In repository Settings > Pages, deploy from the main branch / root.
5. Open the published HTTPS URL in Safari on your iPhone.
6. Tap Share > Add to Home Screen.

PRIVACY / LIMITATIONS
- No account or subscription is required.
- Data is stored locally in the browser; it does not automatically sync between devices.
- Clearing Safari website data can erase app data. Export backups.
- This is a personal tracker, not a medical or training prescription.
- The wake-up progression is adjustable; protect adequate sleep when moving wake time earlier.
